import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create an ArrayList to store elements
        ArrayList<String> list = new ArrayList<>();

        // Prompt the user to enter an element to insert into the list
        String userInput = JOptionPane.showInputDialog(null, "Enter an element to add to the first position of the list:");

        // Check if the user did not cancel the dialog (i.e., userInput is not null)
        if (userInput != null && !userInput.trim().isEmpty()) {
            // Insert the user input into the first position of the ArrayList
            list.add(0, userInput);

            // Optionally add more elements to demonstrate the list
            // list.add("Second Element");

            // Display the updated list
            JOptionPane.showMessageDialog(null, "Updated List: " + list.toString());
        } else {
            // Handle the case where userInput is null or empty
            JOptionPane.showMessageDialog(null, "No valid input was entered.");
        }
    }
}
