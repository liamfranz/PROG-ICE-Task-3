import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // Create an ArrayList to store user inputs
        ArrayList<String> list = new ArrayList<>();
        String[] options = {"Add Element", "Print Elements with Positions", "Exit"};
        int choice;

        do {
            // Show a dialog with options for the user
            choice = JOptionPane.showOptionDialog(
                    null,
                    "Choose an action:",
                    "ArrayList Manager",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            switch (choice) {
                case 0: // Add Element
                    String element = JOptionPane.showInputDialog(null, "Enter an element to add:");
                    if (element != null && !element.trim().isEmpty()) {
                        list.add(element);
                        JOptionPane.showMessageDialog(null, "Element added.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid input. No element added.");
                    }
                    break;

                case 1: // Print Elements with Positions
                    if (list.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "The list is empty.");
                    } else {
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < list.size(); i++) {
                            sb.append("Position ").append(i).append(": ").append(list.get(i)).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, sb.toString());
                    }
                    break;

                case 2: // Exit
                    JOptionPane.showMessageDialog(null, "Exiting.");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Exiting.");
                    break;
            }
        } while (choice != 2);
    }
}
