import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        // Initialize the ArrayList with some sample data
        ArrayList<String> list = new ArrayList<>();
        list.add("Mshayi");
        list.add("Tarenzo");
        list.add("Chustar");
        list.add("Team Sebenza");
        list.add("Mr Thela");

        // Convert the list to a displayable string for the current state
        StringBuilder currentListDisplay = new StringBuilder("Current ArrayList elements:\n");
        for (int i = 0; i < list.size(); i++) {
            currentListDisplay.append(i + 1).append(": ").append(list.get(i)).append("\n");
        }

        // Show the current ArrayList elements
        JOptionPane.showMessageDialog(null, currentListDisplay.toString(), "ArrayList Elements", JOptionPane.INFORMATION_MESSAGE);

        // Ask the user if they want to sort the list
        int response = JOptionPane.showConfirmDialog(null, "Do you want to sort the ArrayList?", "Confirm Sort", JOptionPane.YES_NO_OPTION);

        // If the user confirms, sort the list
        if (response == JOptionPane.YES_OPTION) {
            // Sort the list
            Collections.sort(list);

            // Convert the sorted list to a displayable string
            StringBuilder sortedListDisplay = new StringBuilder("Sorted ArrayList elements:\n");
            for (int i = 0; i < list.size(); i++) {
                sortedListDisplay.append(i + 1).append(": ").append(list.get(i)).append("\n");
            }

            // Show the sorted ArrayList elements
            JOptionPane.showMessageDialog(null, sortedListDisplay.toString(), "Sorted ArrayList Elements", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Inform the user that no changes were made
            JOptionPane.showMessageDialog(null, "No changes were made to the ArrayList.", "No Changes", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
