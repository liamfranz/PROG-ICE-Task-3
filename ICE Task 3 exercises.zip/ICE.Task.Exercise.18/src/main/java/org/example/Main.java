import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // Create an ArrayList to store user inputs
        ArrayList<String> list = new ArrayList<>();
        String[] options = {"Add Element", "Check If Empty", "Display List", "Exit"};
        int choice;

        do {
            // Show a dialog with options for the user
            choice = JOptionPane.showOptionDialog(
                    null,
                    "Choose an action:",
                    "ArrayList Manager",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            switch (choice) {
                case 0: // Add Element
                    String element = JOptionPane.showInputDialog(null, "Enter an element to add:");
                    if (element != null && !element.trim().isEmpty()) {
                        list.add(element);
                        JOptionPane.showMessageDialog(null, "Element added.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid input. No element added.");
                    }
                    break;

                case 1: // Check If Empty
                    if (list.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "The list is empty.");
                    } else {
                        JOptionPane.showMessageDialog(null, "The list is not empty.");
                    }
                    break;

                case 2: // Display List
                    String listStr = list.isEmpty() ? "The list is empty." : list.toString();
                    JOptionPane.showMessageDialog(null, "Current List: " + listStr);
                    break;

                case 3: // Exit
                    JOptionPane.showMessageDialog(null, "Exiting.");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Exiting.");
                    break;
            }
        } while (choice != 3);
    }
}
