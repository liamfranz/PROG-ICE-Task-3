import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Initialize the source ArrayList with some sample data
        ArrayList<String> sourceList = new ArrayList<>();
        sourceList.add("GTR");
        sourceList.add("Bentley");
        sourceList.add("Rollz Royce");
        sourceList.add("Brabus");
        sourceList.add("Merc");

        // Convert the source list to a displayable string
        StringBuilder sourceListDisplay = new StringBuilder("Source ArrayList elements:\n");
        for (int i = 0; i < sourceList.size(); i++) {
            sourceListDisplay.append(i + 1).append(": ").append(sourceList.get(i)).append("\n");
        }

        // Show the source ArrayList elements
        JOptionPane.showMessageDialog(null, sourceListDisplay.toString(), "Source ArrayList Elements", JOptionPane.INFORMATION_MESSAGE);

        // Copy the source ArrayList into a new ArrayList
        ArrayList<String> copiedList = new ArrayList<>(sourceList);

        // Convert the copied list to a displayable string
        StringBuilder copiedListDisplay = new StringBuilder("Copied ArrayList elements:\n");
        for (int i = 0; i < copiedList.size(); i++) {
            copiedListDisplay.append(i + 1).append(": ").append(copiedList.get(i)).append("\n");
        }

        // Show the copied ArrayList elements
        JOptionPane.showMessageDialog(null, copiedListDisplay.toString(), "Copied ArrayList Elements", JOptionPane.INFORMATION_MESSAGE);

        // Optionally, inform the user that the copy operation was successful
        JOptionPane.showMessageDialog(null, "The ArrayList has been copied successfully.", "Operation Completed", JOptionPane.INFORMATION_MESSAGE);
    }
}
