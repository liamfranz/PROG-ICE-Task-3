import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Initialize the ArrayList with some sample data
        ArrayList<String> list = new ArrayList<>();
        list.add("Team Sebenza");
        list.add("Mshayi");
        list.add("Chuster");
        list.add("Mr Thela");
        list.add("Tarenzo");

        // Convert the list to a displayable string for the current state
        StringBuilder listDisplay = new StringBuilder("Current ArrayList elements:\n");
        for (int i = 0; i < list.size(); i++) {
            listDisplay.append(i + 1).append(": ").append(list.get(i)).append("\n");
        }

        // Show the current ArrayList elements
        JOptionPane.showMessageDialog(null, listDisplay.toString(), "ArrayList Elements", JOptionPane.INFORMATION_MESSAGE);

        // Prompt the user to enter the element to search for
        String searchQuery = JOptionPane.showInputDialog(null, "Enter the element you want to search for:");

        if (searchQuery != null) {
            // Check if the ArrayList contains the element
            if (list.contains(searchQuery)) {
                // Find the index of the element
                int index = list.indexOf(searchQuery);
                // Show a message with the index of the element
                JOptionPane.showMessageDialog(null, "Element \"" + searchQuery + "\" found at index " + (index + 1) + ".", "Search Result", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
}

