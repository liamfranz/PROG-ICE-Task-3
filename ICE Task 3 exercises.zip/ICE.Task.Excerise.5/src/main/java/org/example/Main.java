import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        // Initialize the array with some sample data
        String[] array = {"Mr Thela", "Mshayi", "Chustar", "King Lee", "Team Sebenza"};

        // Convert array to a displayable string for the initial state
        StringBuilder initialArrayDisplay = new StringBuilder("Current array elements:\n");
        for (int i = 0; i < array.length; i++) {
            initialArrayDisplay.append(i).append(": ").append(array[i]).append("\n");
        }

        // Show the current array elements
        JOptionPane.showMessageDialog(null, initialArrayDisplay.toString(), "Array Elements", JOptionPane.INFORMATION_MESSAGE);

        // Prompt the user to enter the index of the element to update
        String indexInput = JOptionPane.showInputDialog(null, "Enter the index of the element you want to update:");

        try {
            int index = Integer.parseInt(indexInput);

            // Check if the index is within the valid range
            if (index >= 0 && index < array.length) {
                // Prompt the user to enter the new value
                String newValue = JOptionPane.showInputDialog(null, "Enter the new value for index " + index + ":");

                // Update the array element at the specified index
                array[index] = newValue;

                // Convert updated array to a displayable string
                StringBuilder updatedArrayDisplay = new StringBuilder("Updated array elements:\n");
                for (int i = 0; i < array.length; i++) {
                    updatedArrayDisplay.append(i).append(": ").append(array[i]).append("\n");
                }

                // Display the updated array elements
                JOptionPane.showMessageDialog(null, updatedArrayDisplay.toString(), "Updated Array Elements", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Handle the case where the index is out of bounds
                JOptionPane.showMessageDialog(null, "Invalid index. Please enter an index between 0 and " + (array.length - 1) + ".", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            // Handle the case where the input is not a valid integer
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer index.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
