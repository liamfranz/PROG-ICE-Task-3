import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Initialize the ArrayList and populate it with some sample data
        ArrayList<String> list = new ArrayList<>();
        list.add("Lil Wayne");
        list.add("21 Savage");
        list.add("Mr Thela");
        list.add("Black Coffee");
        list.add("Playboi Carti");

        // Prompt the user to enter an index
        String indexInput = JOptionPane.showInputDialog(null, "Enter the index of the element you want to retrieve:");

        try {
            // Convert the input to an integer
            int index = Integer.parseInt(indexInput);

            // Retrieve the element at the specified index
            if (index >= 0 && index < list.size()) {
                String element = list.get(index);
                // Display the element
                JOptionPane.showMessageDialog(null, "Element at index " + index + ": " + element);
            } else {
                // Handle index out of bounds
                JOptionPane.showMessageDialog(null, "Index out of bounds. Please enter an index between 0 and " + (list.size() - 1) + ".");
            }
        } catch (NumberFormatException e) {
            // Handle the case where the input is not a valid integer
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer.");
        }
    }
}
