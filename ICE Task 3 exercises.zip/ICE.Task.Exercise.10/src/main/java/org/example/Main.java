import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        // Initialize the ArrayList with some sample data
        ArrayList<String> list = new ArrayList<>();
        list.add("GTR");
        list.add("Benz");
        list.add("Toyota");
        list.add("Dodge");
        list.add("Mustang");

        // Convert the list to a displayable string for the current state
        StringBuilder listDisplay = new StringBuilder("Current ArrayList elements:\n");
        for (int i = 0; i < list.size(); i++) {
            listDisplay.append(i + 1).append(": ").append(list.get(i)).append("\n");
        }

        // Show the current ArrayList elements
        JOptionPane.showMessageDialog(null, listDisplay.toString(), "ArrayList Elements", JOptionPane.INFORMATION_MESSAGE);

        // Ask the user if they want to shuffle the list
        int response = JOptionPane.showConfirmDialog(null, "Do you want to shuffle the ArrayList?", "Confirm Shuffle", JOptionPane.YES_NO_OPTION);

        // If the user confirms, shuffle the list
        if (response == JOptionPane.YES_OPTION) {
            // Shuffle the list
            Collections.shuffle(list);

            // Convert the shuffled list to a displayable string
            StringBuilder shuffledListDisplay = new StringBuilder("Shuffled ArrayList elements:\n");
            for (int i = 0; i < list.size(); i++) {
                shuffledListDisplay.append(i + 1).append(": ").append(list.get(i)).append("\n");
            }

            // Show the shuffled ArrayList elements
            JOptionPane.showMessageDialog(null, shuffledListDisplay.toString(), "Shuffled ArrayList Elements", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Inform the user that no changes were made
            JOptionPane.showMessageDialog(null, "No changes were made to the ArrayList.", "No Changes", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
