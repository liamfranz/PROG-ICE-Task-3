rootProject.name = "ICE.Task.Exercise.15"

