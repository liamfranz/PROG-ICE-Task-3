import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // Create two ArrayLists to store the elements
        ArrayList<String> list1 = new ArrayList<>();
        ArrayList<String> list2 = new ArrayList<>();

        // Collect elements for the first ArrayList
        JOptionPane.showMessageDialog(null, "Enter elements for the first list. Type 'done' when finished.");
        String input;
        do {
            input = JOptionPane.showInputDialog(null, "Enter an element for the first list (or type 'done' to finish):");
            if (input != null && !input.trim().equalsIgnoreCase("done")) {
                list1.add(input);
            }
        } while (input != null && !input.trim().equalsIgnoreCase("done"));

        // Collect elements for the second ArrayList
        JOptionPane.showMessageDialog(null, "Enter elements for the second list. Type 'done' when finished.");
        do {
            input = JOptionPane.showInputDialog(null, "Enter an element for the second list (or type 'done' to finish):");
            if (input != null && !input.trim().equalsIgnoreCase("done")) {
                list2.add(input);
            }
        } while (input != null && !input.trim().equalsIgnoreCase("done"));

        // Join the two ArrayLists
        ArrayList<String> combinedList = new ArrayList<>(list1);
        combinedList.addAll(list2);

        // Display the combined ArrayList
        StringBuilder result = new StringBuilder("Combined List:\n");
        for (String item : combinedList) {
            result.append(item).append("\n");
        }

        JOptionPane.showMessageDialog(null, result.toString());
    }
}
