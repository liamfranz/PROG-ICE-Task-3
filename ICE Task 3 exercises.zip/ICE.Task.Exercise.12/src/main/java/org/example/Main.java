import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // Create an ArrayList to store the elements
        ArrayList<String> list = new ArrayList<>();

        // Collect elements from the user
        String input;
        do {
            input = JOptionPane.showInputDialog(null, "Enter an element to add to the list (or type 'done' to finish):");
            if (input != null && !input.trim().equalsIgnoreCase("done")) {
                list.add(input);
            }
        } while (input != null && !input.trim().equalsIgnoreCase("done"));

        // Get the start and end indices from the user
        int startIndex = -1;
        int endIndex = -1;

        try {
            String startStr = JOptionPane.showInputDialog(null, "Enter the start index for the sublist:");
            if (startStr != null) {
                startIndex = Integer.parseInt(startStr);
            }

            String endStr = JOptionPane.showInputDialog(null, "Enter the end index for the sublist:");
            if (endStr != null) {
                endIndex = Integer.parseInt(endStr);
            }

            // Validate indices
            if (startIndex < 0 || endIndex >= list.size() || startIndex > endIndex) {
                JOptionPane.showMessageDialog(null, "Invalid indices. Please make sure start and end indices are within bounds and start is less than or equal to end.");
                return;
            }

            // Extract the sublist
            List<String> sublist = list.subList(startIndex, endIndex + 1);

            // Display the extracted sublist
            StringBuilder result = new StringBuilder("Extracted Sublist:\n");
            for (String item : sublist) {
                result.append(item).append("\n");
            }

            JOptionPane.showMessageDialog(null, result.toString());

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid integers for indices.");
        }
    }
}
