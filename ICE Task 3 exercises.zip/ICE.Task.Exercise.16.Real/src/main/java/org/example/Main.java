import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // Create an ArrayList to store user inputs
        ArrayList<String> originalList = new ArrayList<>();

        // Define the number of elements (fixed at 5)
        final int NUM_ELEMENTS = 5;

        // Collect exactly 5 elements from the user
        for (int i = 0; i < NUM_ELEMENTS; i++) {
            String element = JOptionPane.showInputDialog(null, "Enter element " + (i + 1) + ":");
            if (element != null) {
                originalList.add(element);
            } else {
                JOptionPane.showMessageDialog(null, "No input detected. Exiting.");
                return;
            }
        }

        // Clone the original list
        ArrayList<String> clonedList = new ArrayList<>(originalList);

        // Convert lists to strings for display
        String originalListStr = originalList.toString();
        String clonedListStr = clonedList.toString();

        // Show the original and cloned lists in dialog boxes
        JOptionPane.showMessageDialog(null, "Original List: " + originalListStr);
        JOptionPane.showMessageDialog(null, "Cloned List: " + clonedListStr);
    }
}
