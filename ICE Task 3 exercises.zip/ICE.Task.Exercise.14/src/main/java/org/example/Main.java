import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // Create an ArrayList to store the elements
        ArrayList<String> list = new ArrayList<>();

        // Collect elements from the user
        String input;
        do {
            input = JOptionPane.showInputDialog(null, "Enter an element to add to the list (or type 'done' to finish):");
            if (input != null && !input.trim().equalsIgnoreCase("done")) {
                list.add(input);
            }
        } while (input != null && !input.trim().equalsIgnoreCase("done"));

        // Display the list before swapping
        JOptionPane.showMessageDialog(null, "Current List:\n" + list);

        // Get the indices to swap
        int index1 = -1;
        int index2 = -1;

        try {
            String index1Str = JOptionPane.showInputDialog(null, "Enter the index of the first element to swap:");
            if (index1Str != null) {
                index1 = Integer.parseInt(index1Str);
            }

            String index2Str = JOptionPane.showInputDialog(null, "Enter the index of the second element to swap:");
            if (index2Str != null) {
                index2 = Integer.parseInt(index2Str);
            }

            // Validate indices
            if (index1 < 0 || index1 >= list.size() || index2 < 0 || index2 >= list.size()) {
                JOptionPane.showMessageDialog(null, "Invalid indices. Please make sure indices are within bounds.");
                return;
            }

            // Swap the elements
            String temp = list.get(index1);
            list.set(index1, list.get(index2));
            list.set(index2, temp);

            // Display the list after swapping
            JOptionPane.showMessageDialog(null, "List after swapping:\n" + list);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid integers for indices.");
        }
    }
}
