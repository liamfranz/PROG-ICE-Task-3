rootProject.name = "ICE.Task.Exercise.2"

