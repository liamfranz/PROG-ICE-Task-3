import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Initialize the ArrayList with some sample data
        ArrayList<String> list = new ArrayList<>();
        list.add("Mr Thela");
        list.add("Mshayi");
        list.add("Chuster");
        list.add("Dj Ngamla");
        list.add("Team Sebenza");

        // Convert the list to a displayable string for the current state
        StringBuilder currentListDisplay = new StringBuilder("Current ArrayList elements:\n");
        for (int i = 0; i < list.size(); i++) {
            currentListDisplay.append(i + 1).append(": ").append(list.get(i)).append("\n");
        }

        // Show the current ArrayList elements
        JOptionPane.showMessageDialog(null, currentListDisplay.toString(), "ArrayList Elements", JOptionPane.INFORMATION_MESSAGE);

        // Check if the ArrayList has at least 3 elements
        if (list.size() >= 3) {
            // Ask the user for confirmation to remove the third element
            int response = JOptionPane.showConfirmDialog(null, "Do you want to remove the third element?", "Confirm Removal", JOptionPane.YES_NO_OPTION);

            // If the user confirms, remove the third element
            if (response == JOptionPane.YES_OPTION) {
                list.remove(2);

                // Convert the updated list to a displayable string
                StringBuilder updatedListDisplay = new StringBuilder("Updated ArrayList elements:\n");
                for (int i = 0; i < list.size(); i++) {
                    updatedListDisplay.append(i + 1).append(": ").append(list.get(i)).append("\n");
                }

                // Show the updated ArrayList elements
                JOptionPane.showMessageDialog(null, updatedListDisplay.toString(), "Updated ArrayList Elements", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Inform the user that no changes were made
                JOptionPane.showMessageDialog(null, "No changes were made to the ArrayList.", "No Changes", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            // Handle the case where there are fewer than 3 elements
            JOptionPane.showMessageDialog(null, "The ArrayList does not have enough elements to remove the third one.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
