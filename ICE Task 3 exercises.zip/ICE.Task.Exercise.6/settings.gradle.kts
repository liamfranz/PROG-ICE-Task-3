rootProject.name = "ICE.Task.Exercise.6"

