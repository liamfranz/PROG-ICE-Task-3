import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Collections;

public class Main {

    public static void main(String[] args) {
        // Create an ArrayList to store the elements
        ArrayList<String> list = new ArrayList<>();

        // Collect elements from the user
        String input;
        do {
            input = JOptionPane.showInputDialog(null, "Enter an element to add to the list (or type 'done' to finish):");
            if (input != null && !input.trim().equalsIgnoreCase("done")) {
                list.add(input);
            }
        } while (input != null && !input.trim().equalsIgnoreCase("done"));

        // Reverse the ArrayList
        Collections.reverse(list);

        // Display the reversed ArrayList
        StringBuilder reversedList = new StringBuilder("Reversed List:\n");
        for (String item : list) {
            reversedList.append(item).append("\n");
        }

        JOptionPane.showMessageDialog(null, reversedList.toString());
    }
}
