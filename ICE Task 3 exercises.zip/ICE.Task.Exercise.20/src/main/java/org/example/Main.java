import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // Create an ArrayList to store user inputs
        ArrayList<String> list = new ArrayList<>();
        String[] options = {"Add Element", "Increase Capacity", "Display List", "Exit"};
        int choice;

        do {
            // Show a dialog with options for the user
            choice = JOptionPane.showOptionDialog(
                    null,
                    "Choose an action:",
                    "ArrayList Manager",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            switch (choice) {
                case 0: // Add Element
                    String element = JOptionPane.showInputDialog(null, "Enter an element to add:");
                    if (element != null && !element.trim().isEmpty()) {
                        list.add(element);
                        JOptionPane.showMessageDialog(null, "Element added.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid input. No element added.");
                    }
                    break;

                case 1: // Increase Capacity
                    // Ask the user for the desired capacity
                    String capacityStr = JOptionPane.showInputDialog(null, "Enter the desired capacity:");
                    int desiredCapacity;

                    try {
                        desiredCapacity = Integer.parseInt(capacityStr);
                        if (desiredCapacity <= list.size()) {
                            JOptionPane.showMessageDialog(null, "Desired capacity must be greater than the current size of the list. No change made.");
                        } else {
                            // Increase the capacity of the list to the desired capacity
                            list.ensureCapacity(desiredCapacity);
                            JOptionPane.showMessageDialog(null, "Capacity increased to " + desiredCapacity + ".");
                        }
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid number format. No change made.");
                    }
                    break;

                case 2: // Display List
                    String listStr = list.isEmpty() ? "The list is empty." : list.toString();
                    JOptionPane.showMessageDialog(null, "Current List: " + listStr);
                    break;

                case 3: // Exit
                    JOptionPane.showMessageDialog(null, "Exiting.");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Exiting.");
                    break;
            }
        } while (choice != 3);
    }
}
