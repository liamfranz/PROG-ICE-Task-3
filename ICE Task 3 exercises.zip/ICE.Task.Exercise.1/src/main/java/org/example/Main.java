import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create an ArrayList to store color names
        ArrayList<String> colors = new ArrayList<>();

        // Prompt the user to enter colors
        while (true) {
            // Get user input for a color
            String input = JOptionPane.showInputDialog(null, "Enter a color (or leave blank to finish):", "Color Input", JOptionPane.PLAIN_MESSAGE);

            // Check if the user has canceled the input dialog
            if (input == null) {
                JOptionPane.showMessageDialog(null, "Operation canceled.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            // If the user entered an empty string, break the loop
            if (input.trim().isEmpty()) {
                break;
            }

            // Add the entered color to the ArrayList
            colors.add(input.trim());
        }

        // Prepare the output string
        StringBuilder colorList = new StringBuilder("Color List:\n");
        for (String color : colors) {
            colorList.append(color).append("\n");
        }

        // Display the list of colors
        JOptionPane.showMessageDialog(null, colorList.toString(), "Colors", JOptionPane.INFORMATION_MESSAGE);
    }
}
